<html>
    <head><title> javascript</title></head>
    <body>
        <script lenguaje="javaScript">
            alert("bienvenido al mundo de javaScript");
            var nom;
            nom=prompt("como te llamas");
            alert("mucho gusto "+ nom);
            var num1,num2;
            num1=prompt("esciba un numero");
            num2=prompt("esciba un numero");
            alert("el primer numero que escribio es "+ num1);
            alert("el segundo numero que escribio es "+ num2);
            //sume los dos numeros//
            suma=parseInt(num1) + parseInt(num2);
            alert("la suma de los numeros es "+ suma);
            resta=parseInt(num1) - parseInt(num2);
            alert("la resta de los numeros es "+ resta);
            multi=parseInt(num1) * parseInt(num2);
            alert("los numeros multiplicados entre si da "+ multi);
            divi=parseInt(num1) / parseInt(num2);
            alert("la division entre los numeros es "+ divi);
            //cree el codigo para saber el area de un rectangulo solicitando los datos
            //necesarios, lo mismo para el area de un triangulo y un circulo
</script>
<font size="4" color="red" face="comic sans ms">Gracias por participar


