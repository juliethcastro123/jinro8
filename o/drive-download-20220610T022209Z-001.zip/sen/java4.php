<!DOCTYPE html>
<html>
<title>Java 5</title>
<head>
    
</head>
<body>
    <body bgcolor="silver">
    <script type="text/javascript">
        var y;
        y=prompt("generar la tabla de multiplicar ", " ");
        y=parseInt(y);

        for (var x =1; x<=10; x++);{

            r=y*x;
            document.write(y+" x "+x+"="+r+"<br>");


        }
        </script>
