<!DOCTYPE html PUBLIC "-//W3C//DTT HTML 5 //EN">
<html>
    <head>
        <title> mi primer animacion en javascript y css </title>
        <link rel="stylesheet" href="estilo.css">
        <script src="js.js"></script>
</head>

<body>
    <figure class="sena1">
        <img src="imagenes/ima1.jpg" alt="sample38"/>
        <dic class="tittle">
            <div>
                <h2>camilo</h2>
                <h4>sena 2022</h4>
</div>
</div>
<figcaption>
    <p>efecto de la imagen con javascript y css</p>
</figcaption>
<a href="#"></a>
</ficure>


<figure class="sena1">
        <img src="imagenes/ima2.jpg" alt="sample91"/>
        <dic class="tittle">
            <div>
                <h2>ADSI</h2>
                <h4>sena 2022</h4>
</div>
</div>
<figcaption>
    <p>efecto de la imagen con javascript y css</p>
</figcaption>
<a href="#"></a>
</ficure>


<figure class="sena1">
        <img src="imagenes/ima3.jpg" alt="sample100"/>
        <dic class="tittle">
            <div>
                <h2>no se</h2>
                <h4>sena 2022</h4>
</div>
</div>
<figcaption>
    <p>efecto de la imagen con javascript y css</p>
</figcaption>
<a href="#"></a>
</ficure>