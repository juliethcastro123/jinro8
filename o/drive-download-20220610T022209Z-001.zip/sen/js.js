$(".hover").mouse(

    function()(
        $(this).removeClass("hover");
    )
);