<!DOCTYPE html>
<html>
    <head>
        <title>camilo</title>
</head>
<body>
    <header>
        <div class="w3-container w3-black w3-center">
            <h1> bienvenido a sena adsi</h1>

</div>
</header>
<div class="w3-container w3-red">
    <h1><?php echo $_GET['mensaje'];?></h1>
</div>
</body>
</html>