<html>
    <head><title> rectangulo</title></head>
    <body>
        <script lenguaje="javaScript">
            alert("bienvenido al mundo de javaScript");
            var nom;
            nom=prompt("como te llamas");
            alert("mucho gusto "+ nom);
            var num1,num2;
            num1=prompt("esciba el largo dedl rectangulo");
            num2=prompt("esciba el ancho del rectangulo");
            alert("lo largo del rectangulo es "+ num1);
            alert("el ancho del rectangulo es "+ num2);
           
            multi=parseInt(num1) * parseInt(num2);
            alert("el area del rectangulo es de "+ multi);

            var num3,num4;
            num3=prompt("esciba la base del triangulo");
            num4=prompt("esciba la altura del triangulo");
            alert("la base del triangulo es "+ num3);
            alert("la altura del trianagulo es "+ num4);

            multi=parseInt(num3) * parseInt(num4);
            divi=parseInt(multi) / parseInt(2);
            alert("el area de el triangulo es "+ divi);
            
            var pi,radio;
            radio=prompt("digite el readio de un circulo"); 
            pi=parseInt(3.14);
            area=parseInt(pi) * (radio) * (radio);
            alert("el area del circulo es "+ area);


</script>
<font size="4" color="red" face="comic sans ms">Gracias por participar

