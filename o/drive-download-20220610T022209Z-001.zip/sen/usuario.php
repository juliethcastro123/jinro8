<?php

class Usuario{
    private $id;
    private $nombre;
    private $clave;

    public function getId(){
        return$this->id;
    }
    public function setId($Id){
        $this-> id = $id;
    }
    public function getNombre(){
        return $this->nombre;
    }
    public function setNombre(){
        $this-> $nombre
    }
    public function getClave(){
        return $this->clave;
    }
    public function setClave($clave){
        $this-> $clave;
    }
}