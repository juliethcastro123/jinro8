<center>
    <font size="6"  color="white" face="comic sans ms"><b>suscribete<p>
        <form method="post" name="" action="">
                <table width="50%" border="0" cellpading="10" cellspacing="0">
                <tr>
                    <th>registro <input type="text" name="registro" size="25" maxlength="50">
                    <td align="center">
                    <input type="submit" value="enviar">
</th></td>
                </tr>
            </table></form><p><p>

            <h5><font color="purple">pap</font></h5>