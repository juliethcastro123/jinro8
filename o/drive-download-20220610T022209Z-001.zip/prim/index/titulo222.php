<table width="100%"  bgcolor="purple" border="0">
    <tr align="center"><td><font size="4" color="grey" face="comic sans ms"><b><img src="imagenes/logo.png" width="500" height="150">
     </b></td></tr></table><p><p>
   


<!-- para el check
     <input type="checkbox" id="chack">
        <label for="check" class="checkbtn"> -->