<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> jinro </title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav>
    <div class="icono-menu">
        <img src="img/open-menu.png" id="icono-menu">
    </div>
    
    
    <div class="cont-menu active" id="menu">
    <font face="comic sans ms"><ul>
            <li> Cervezas </li>
            <li> Licores </li>
            <li> Sin alcohol </li>
            <li> Snacks </li>
            <li> Promociones </li>
            <li> Salir </li>
        </ul></font>
    </div>
    </nav>
    <script src="app.js"></script>
</body>
</html>
