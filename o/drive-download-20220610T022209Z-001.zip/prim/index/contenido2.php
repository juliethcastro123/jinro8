<table width="100%" border="0" cellpadding="10" cellspacing="0">
    <tr><td><center><img src="img/sixcorona.jpg" width="150" height="120"><p>
    <font size="4" color="black" face="comic sans ms"><b>Six pack<br>corona 210ml<p>$20.000.00</b></font></center></td><p><p>
    <td><center><img src="img/sixreds.jpg" width="150" height="120"><p>
    <font size="4" color="black" face="comic sans ms"><b>Six pack<br>redds 210ml<p>$25.000.00</b></font></center></td><p><p></center></td>
    <td><center><img src="img/back.jpg" width="150" height="120"><p>
    <font size="4" color="black" face="comic sans ms"><b>Botella black & <br>white 700ml<p>$56.000.00</b></font></center></td><p><p></center></td>
    <td><center><img src="img/botellajhon.jpg" width="150" height="120"><p>
    <font size="4" color="black" face="comic sans ms"><b>Botella johnnie<br>walker 700ml<p>$70.000.00</b></font></center></td><p><p></center></td>


</td></tr></table><p><p><br><br><br><br><br><br><br><br><br>
    
