<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="licor">
       <h5><font color="purple">ppp</h5></font><center><tr align="center"><p><td><img src="img/logo.png" class="licimg" width="120" 
    height="52" ></center>
        </b></td></tr><p><p>
</div>

<table width="100%" border="0" cellpadding="10" cellspacing="0">
        <tr align="center"><td><img src="img/licores.jpg" width="800" height="700">
        </b></td></tr></table><p><p>

        
</body>
</html>