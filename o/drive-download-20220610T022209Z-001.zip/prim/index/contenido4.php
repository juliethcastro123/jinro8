<center>
    <h1><font color="white" face="comic sans ms">siguenos</font></h1><p><center><img src="img/face.png" width="40" height="40"><img src="img/insta.png" width="40" height="40"></center>