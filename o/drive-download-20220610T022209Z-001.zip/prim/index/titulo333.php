<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jinro</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <nav>
        

        <a class="enlace">
            <button class="toggle">
            <img class="hambur" src="imagenes/barra.png">
            </button>
            <img src="imagenes/logo.png" alt="" class="logo">
        
        <ul>
            <li><a class="active" href="#">inicio</a></li><p>
            <li><a href="#">no se</a></li><p>
            <li><a href="#">no se</a></li><p>
            <li><a href="#">no se</a></li><p>
            <li><a href="#">no se</a></li><p>
        </ul>
    </nav>
    <section></section>
</body>
</html>