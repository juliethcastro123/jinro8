<html>
    <head> <title>Jinro</title>
    <meta http-equiv="Content.Type" contect="text/html; charset=utf-8"/>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
        
        </head><p>
<body><p>
<?php include("index/titulo.php");?>
        <p>

        <?php include("index/contenido1.php");?>

        <p><center>
        <font size="6" color="black" face="comic sans ms"><b>Destacados</b></font></center><p><p>
        
        
        <?php include("index/contenido2.php");?><p>
</body><p>
        <footer class="foo">
        <p>
        <table width="100%" bgcolor="purple" border="0" >
        <tr><th colspan><?php include("index/contenido3.php");?></th>
        <th><?php include ("index/contenido4.php");?></th></tr></table><p><p>
    


</html>     